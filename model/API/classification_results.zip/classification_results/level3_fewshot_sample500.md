# Level-3 Few-shot Summary
- Samples: 500
- Top-1: 38.40% (192/500)
- Top-3: 73.60% (368/500)
- Top-5: 82.00% (410/500)
- Output CSV: model\API\classification_results\level3_fewshot_sample500.csv