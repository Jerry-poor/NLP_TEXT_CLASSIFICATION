# Level-2 Few-shot Summary
- Samples: 500
- Top-1: 42.40% (212/500)
- Top-3: 75.60% (378/500)
- Top-5: 81.60% (408/500)
- Output CSV: model\API\classification_results\level2_fewshot_sample500.csv