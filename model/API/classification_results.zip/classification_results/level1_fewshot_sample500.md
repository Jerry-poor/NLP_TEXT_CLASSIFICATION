# Level-1 Few-shot Summary
- Samples: 500
- Top-1: 50.00% (250/500)
- Top-3: 91.00% (455/500)
- Top-5: 96.00% (480/500)
- Output CSV: model\API\classification_results\level1_fewshot_sample500.csv