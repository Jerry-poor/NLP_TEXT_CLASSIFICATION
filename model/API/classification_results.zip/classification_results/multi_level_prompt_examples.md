# multi_level_few_shot prompt examples (fixed candidate buckets)
(supports = first 3 rows in same bucket where possible; eval sample = random n=5, show first eval prompt)

## Level 1 example
- dataset: Lib_Dataset_Level1_30Nov25_final.xlsx
- true code (for bucket): 000
- candidates: 10

`
You are a Dewey Decimal classifier. Choose the single best category NAME from the allowed list.

Allowed categories:
- Computer science, information, and general works
- Philosophy and psychology
- Religion
- Social sciences
- Language
- Science
- Technology
- Arts and recreation
- Literature
- History and geography

Support examples (3-shot):

Example 1:
Title: The elements of visual grammar
Abstract: A color-illustrated introduction to the basic principles of visual language that every content creator and consumer needs to know, The right images capture attention, pique curiosity, and inspire viewers to stick around long enough to read any accompanying text. Nearly everyone today needs to use or understand images in communications of all kinds, from the most formal professional publication to the most casual social media post, and knowing the basics of visual language is essential for content creators and consumers alike. However, most people aren't taught visual grammar unless they go into art- or design-related fields. The Elements of Visual Grammar explains image use in any media in practical terms for writers, scholars, and other professionals. Award-winning art director and design professor Angela Riechers offers a flexible set of principles and best practices for selecting images that work-and using them in the most persuasive way. The result is an indispensable guide for anyone who wants to learn how to work more successfully with images and words. Features more than 200 color illustrations-drawn from a wide range of styles, media, and eras-that demonstrate the principles of visual grammar and how images can support and enhance written content, Defines and illustrates the basic elements of images, describes how images function within text regardless of media, and explains how to choose images and integrate them with text, Introduces the practical, cultural, conceptual, and scientific factors that influence image use, Analyzes images by function and describes ways to employ symbolism, synecdoche, allegory, metaphor, analogy, and iconography--
True label: ### Computer science, information, and general works ###

Example 2:
Title: Little quick fix
Abstract: A key step in numeracy is being able to read and interpret tables and graphs. It's not as easy as it looks! It gets tested on exams and these are common questions where students will lose marks. This Little Quick Fix will prep students to make sure they're ready to read, interpret and produce tables and graphs that will score them good marks.
True label: ### Computer science, information, and general works ###

Example 3:
Title: 100 activities for teaching research methods 
Abstract: A sourcebook of exercises, games, scenarios and role plays, this practical, user-friendly guide provides a complete and valuable resource for research methods tutors, teachers and lecturers. Developed to complement and enhance existing course materials, the 100 ready-to-use activities encourage innovative and engaging classroom practice in seven areas: finding and using sources of information planning a research project conducting research using and analyzing data disseminating results acting ethically developing deeper research skills. Each of the activities is divided into a section on tutor notes and student handouts. Tutor notes contain clear guidance about the purpose, level and type of activity, along with a range of discussion notes that signpost key issues and research insights. Important terms, related activities and further reading suggestions are also included. Not only does the A4 format make the student handouts easy to photocopy, they are also available to download and print directly from the book's companion website for easy distribution in class.
True label: ### Computer science, information, and general works ###


Now classify the following text. If the allowed list has 5 or fewer items, return ALL of them with confidence. If more than 5, return the top 5. Always pick names ONLY from the allowed list (e.g., "Science: 72%"), one per line.
Text title: Advanced Internet protocols, services, and applications 
Text abstract: Today, the internet and computer networking are essential parts of business, learning, and personal communications and entertainment. Virtually all messages or transactions sent over the internet are carried using internet infrastructure- based on advanced internet protocols. Advanced internet protocols ensure that both public and private networks operate with maximum performance, security, and flexibility. This book is intended to provide a comprehensive technical overview and survey of advanced internet protocols, first providing a solid introduction and going on to discuss internetworking technologies, architectures and protocols. The book also shows application of the concepts in next generation networks and discusses protection and restoration, as well as various tunnelling protocols and applications. The book ends with a thorough discussion of emerging topics--
Answer with names only (with percentages); do NOT output numeric codes.
`

## Level 2 example
- dataset: Lib_Dataset_Level2_27Nov25_final.xlsx
- true code (for bucket): 000
- candidates: 10

`
You are a Dewey Decimal classifier. Choose the single best category NAME from the allowed list.

Allowed categories:
- General works
- Bibliography
- Library and information sciences
- Encyclopedias and books of facts
- Unassigned
- Magazines, journals and serials
- Associations, organizations and museums
- News media, journalism, and publishing
- Quotations
- Manuscripts and rare books

Support examples (3-shot):

Example 1:
Title: Books that changed the world 
Abstract: Examines the content and impact of works, including Common Sense, Das Kapital, and Mein Kampf, that have influenced the course of history.
True label: ### General works ###

Example 2:
Title: Little quick fix 
Abstract: Teaches students how to find their interest, hone it to a topic, and turn it into a research question that is relevant, interesting, and researchable.--
True label: ### General works ###

Example 3:
Title: Handbook to Stonehenge, the Bermuda Triangle, and other mysterious locations 
Abstract: Mysterious places dot the globe. From Stonehenge and the Bermuda Triangle to the Overtoun Bridge and the Yonaguni Ruins, mesmerizing locations are everywhere--
True label: ### General works ###


Now classify the following text. If the allowed list has 5 or fewer items, return ALL of them with confidence. If more than 5, return the top 5. Always pick names ONLY from the allowed list (e.g., "Science: 72%"), one per line.
Text title: Data visualisation 
Text abstract: Voted one of the six best books for data geeks by The Financial Times. Read the review here. Lecturers, request your electronic inspection copy. Never has it been more essential to work in the world of data. Scholars and students need to be able to analyze, design, and curate information into useful tools of communication, insight, and understanding. This book is the starting point in learning the process and skills of data visualization, teaching the concepts and skills of how to present data, and inspiring effective visual design. Benefits of this book A flexible step-by-step journey that equips you to achieve great data visualization A curated collection of classic and contemporary examples, giving illustrations of good and bad practice Examples on every page to give creative inspiration Illustrations of good and bad practice show you how to critically evaluate and improve your own work Advice and experience from the best designers in the field Loads of online practical help, checklists, case studies and exercises make this the most comprehensive text available
Answer with names only (with percentages); do NOT output numeric codes.
`

## Level 3 example
- dataset: Lib_Dataset_Level3_26Nov25_final.xlsx
- true code (for bucket): 001
- candidates: 8

`
You are a Dewey Decimal classifier. Choose the single best category NAME from the allowed list.

Allowed categories:
- Computer science, knowledge, and systems
- Knowledge
- The book (writing, libraries, and book-related topics)
- Systems
- Data processing and computer science
- Computer programming, programs, and data
- Special computer methods (e.g. AI, multimedia, VR)
- 009

Support examples (3-shot):

Example 1:
Title: Methodologies for practice research
Abstract: Sharp and focused, this book provides the need-to-know information on how to design and implement a good, high-quality research project.
True label: ### Knowledge ###

Example 2:
Title: Books that changed the world 
Abstract: Examines the content and impact of works, including Common Sense, Das Kapital, and Mein Kampf, that have influenced the course of history.
True label: ### Knowledge ###

Example 3:
Title: Qualitative research methods
Abstract: Qualitative Research Methods is a comprehensive, all-inclusive resource for the theory and practice of qualitativeethnographic research methodology--
True label: ### Knowledge ###


Now classify the following text. If the allowed list has 5 or fewer items, return ALL of them with confidence. If more than 5, return the top 5. Always pick names ONLY from the allowed list (e.g., "Science: 72%"), one per line.
Text title: Practical statistics for data scientists
Text abstract: Statistical methods are a key part of data science, yet few data scientists have formal statistical training. Courses and books on basic statistics rarely cover the topic from a data science perspective. The second edition of this practical guide-now including examples in Python as well as R-explains how to apply various statistical methods to data science, tells you how to avoid their misuse, and gives you advice on what's important and what's not. Many data scientists use statistical methods but lack a deeper statistical perspective. If you're familiar with the R or Python programming languages, and have had some exposure to statistics but want to learn more, this quick reference bridges the gap in an accessible, readable format. With this updated edition, you'll dive into: Exploratory data analysis Data and sampling distributions Statistical experiments and significance testing Regression and prediction Classification Statistical machine learning Unsupervised learning.--
Answer with names only (with percentages); do NOT output numeric codes.
`
